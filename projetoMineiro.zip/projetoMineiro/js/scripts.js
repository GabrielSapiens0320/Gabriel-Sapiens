// SCROLL 

let navBtn = $('.nav-item');

let bannerSection = $('#mainSlider');
let aboutSection = $('#home-area');
let institutionalSection = $('#institutional-area');
let niveisSection = $('#niveis-area');
let matriculasSection = $('#matriculas-area');
let contactSection = $('#contact-area');

let scrollTo = '';

$(navBtn).click(function() {

  let btnId = $(this).attr('id');

  if(btnId == 'home-menu') {
    scrollTo = bannerSection;
  } else if(btnId == 'institutional-menu') {
    scrollTo = institutionalSection;
  } else if(btnId == 'niveis-menu') {
    scrollTo = niveisSection;
  } else if(btnId == 'matriculas-menu') {
    scrollTo = matriculasSection;
  } else if(btnId == 'contact-menu') {
    scrollTo = contactSection;
  } else {
    scrollTo = bannerSection;
  }

  $([document.documentElement, document.body]).animate({
      scrollTop: $(scrollTo).offset().top - 70
  }, 1500);
});

